#include "tokenStack.h"
int doOperator(struct tokenStack *stack, char *o);
